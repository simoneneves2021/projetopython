# projetoPython
backand do projeto python treinamento python senac em 2021
